# tests/test_maze.py — Tests unitaires de la structure de données Maze.
# Vérifie le bon fonctionnement de la classe Maze, notamment :
#   - la création d'un labyrinthe aux dimensions correctes
#   - l'accès et la modification des murs de chaque cellule
#   - la détection des incohérences entre cellules voisines
#   - la détection des zones ouvertes 3x3 interdites
#   - le placement correct du motif "42" et sa détection
#   - l'encodage hexadécimal de la grille (correspondance bits/directions)
#   - les cas limites : labyrinthe 1x1, dimensions
# minimales, trop petit pour "42"

import pytest
from model.maze import Maze


# ── Fixtures ──────────────────────────────────────────────────────────


@pytest.fixture
def maze_5x5() -> Maze:
    return Maze(5, 5, entry=(0, 0), exit=(4, 4))


@pytest.fixture
def maze_3x3() -> Maze:
    return Maze(3, 3, entry=(0, 0), exit=(2, 2))


# ── Initialisation ────────────────────────────────────────────────────


def test_init_dimensions(maze_5x5: Maze) -> None:
    assert maze_5x5.width == 5
    assert maze_5x5.height == 5
    assert len(maze_5x5.grid) == 5
    assert len(maze_5x5.grid[0]) == 5


def test_init_all_cells_full_wall(maze_5x5: Maze) -> None:
    """Toutes les cellules doivent commencer à 15 (4 murs)."""
    for row in maze_5x5.grid:
        for cell in row:
            assert cell == 15


def test_init_1x1() -> None:
    maze = Maze(1, 1, entry=(0, 0), exit=(0, 0))
    assert maze.width == 1
    assert maze.height == 1
    assert maze.grid[0][0] == 15


def test_init_rectangular() -> None:
    maze = Maze(10, 3, entry=(0, 0), exit=(9, 2))
    assert maze.width == 10
    assert maze.height == 3
    assert len(maze.grid) == 3
    assert len(maze.grid[0]) == 10


# ── has_wall ──────────────────────────────────────────────────────────


def test_has_wall_all_directions_initially(maze_3x3: Maze) -> None:
    for y in range(3):
        for x in range(3):
            for direction in ('N', 'E', 'S', 'W'):
                assert maze_3x3.has_wall(x, y, direction) is True


def test_has_wall_invalid_direction_raises(maze_3x3: Maze) -> None:
    with pytest.raises(ValueError):
        maze_3x3.has_wall(1, 1, 'X')


# ── remove_wall ───────────────────────────────────────────────────────


def test_remove_wall_east_is_symmetric(maze_5x5: Maze) -> None:
    """Retirer le mur Est de (1,1) doit aussi retirer le mur Ouest de (2,1)."""
    maze_5x5.remove_wall(1, 1, 'E')
    assert maze_5x5.has_wall(1, 1, 'E') is False
    assert maze_5x5.has_wall(2, 1, 'W') is False
    # Les autres murs ne doivent pas être affectés
    assert maze_5x5.has_wall(1, 1, 'N') is True
    assert maze_5x5.has_wall(1, 1, 'S') is True


def test_remove_wall_west_is_symmetric(maze_5x5: Maze) -> None:
    """Retirer le mur Ouest de (2,2) doit aussi retirer le mur Est de (1,2)."""
    maze_5x5.remove_wall(2, 2, 'W')
    assert maze_5x5.has_wall(2, 2, 'W') is False
    assert maze_5x5.has_wall(1, 2, 'E') is False


def test_remove_wall_north_is_symmetric(maze_5x5: Maze) -> None:
    """Retirer le mur Nord de (2,2) doit aussi retirer le mur Sud de (2,1)."""
    maze_5x5.remove_wall(2, 2, 'N')
    assert maze_5x5.has_wall(2, 2, 'N') is False
    assert maze_5x5.has_wall(2, 1, 'S') is False


def test_remove_wall_south_is_symmetric(maze_5x5: Maze) -> None:
    """Retirer le mur Sud de (1,1) doit aussi retirer le mur Nord de (1,2)."""
    maze_5x5.remove_wall(1, 1, 'S')
    assert maze_5x5.has_wall(1, 1, 'S') is False
    assert maze_5x5.has_wall(1, 2, 'N') is False


def test_remove_wall_east_at_boundary_raises(maze_5x5: Maze) -> None:
    """Retirer le mur Est de la dernière colonne doit lever ValueError."""
    with pytest.raises(ValueError):
        maze_5x5.remove_wall(4, 0, 'E')


def test_remove_wall_west_at_boundary_raises(maze_5x5: Maze) -> None:
    with pytest.raises(ValueError):
        maze_5x5.remove_wall(0, 0, 'W')


def test_remove_wall_north_at_boundary_raises(maze_5x5: Maze) -> None:
    with pytest.raises(ValueError):
        maze_5x5.remove_wall(0, 0, 'N')


def test_remove_wall_south_at_boundary_raises(maze_5x5: Maze) -> None:
    with pytest.raises(ValueError):
        maze_5x5.remove_wall(0, 4, 'S')


# ── set_wall ──────────────────────────────────────────────────────────


def test_set_wall_restores_after_remove(maze_5x5: Maze) -> None:
    """set_wall doit remettre le mur après un remove_wall."""
    maze_5x5.remove_wall(1, 1, 'E')
    assert maze_5x5.has_wall(1, 1, 'E') is False
    maze_5x5.set_wall(1, 1, 'E')
    assert maze_5x5.has_wall(1, 1, 'E') is True


def test_set_wall_invalid_direction_raises(maze_5x5: Maze) -> None:
    with pytest.raises(ValueError):
        maze_5x5.set_wall(1, 1, 'Z')


# ── encode_hex ────────────────────────────────────────────────────────


def test_encode_hex_initial_all_f(maze_3x3: Maze) -> None:
    """Labyrinthe plein → toutes les cellules encodées 'F'."""
    hex_str = maze_3x3.encode_hex()
    lines = hex_str.strip().split('\n')
    assert len(lines) == 3
    for line in lines:
        assert line == 'FFF'


def test_encode_hex_changes_after_remove(maze_3x3: Maze) -> None:
    """Retirer un mur change la valeur hex correspondante."""
    before = maze_3x3.encode_hex()
    maze_3x3.remove_wall(1, 1, 'E')
    after = maze_3x3.encode_hex()
    assert before != after


def test_encode_hex_format(maze_3x3: Maze) -> None:
    """encode_hex retourne WIDTH caractères par ligne + \\n."""
    hex_str = maze_3x3.encode_hex()
    lines = hex_str.split('\n')
    # La dernière ligne peut être vide à cause du \n final
    non_empty = [li for li in lines if li]
    assert len(non_empty) == 3
    for line in non_empty:
        assert len(line) == 3


# ── add_wall ──────────────────────────────────────────────────────────


def test_add_wall_east_is_symmetric(maze_5x5: Maze) -> None:
    """add_wall(E) doit aussi remettre le mur Ouest du voisin."""
    maze_5x5.remove_wall(1, 1, 'E')
    maze_5x5.add_wall(1, 1, 'E')
    assert maze_5x5.has_wall(1, 1, 'E') is True
    assert maze_5x5.has_wall(2, 1, 'W') is True


def test_add_wall_south_is_symmetric(maze_5x5: Maze) -> None:
    maze_5x5.remove_wall(2, 2, 'S')
    maze_5x5.add_wall(2, 2, 'S')
    assert maze_5x5.has_wall(2, 2, 'S') is True
    assert maze_5x5.has_wall(2, 3, 'N') is True


def test_add_wall_north_is_symmetric(maze_5x5: Maze) -> None:
    maze_5x5.remove_wall(2, 2, 'N')
    maze_5x5.add_wall(2, 2, 'N')
    assert maze_5x5.has_wall(2, 2, 'N') is True
    assert maze_5x5.has_wall(2, 1, 'S') is True


def test_add_wall_west_is_symmetric(maze_5x5: Maze) -> None:
    maze_5x5.remove_wall(2, 2, 'W')
    maze_5x5.add_wall(2, 2, 'W')
    assert maze_5x5.has_wall(2, 2, 'W') is True
    assert maze_5x5.has_wall(1, 2, 'E') is True


def test_add_wall_invalid_direction_raises(maze_5x5: Maze) -> None:
    with pytest.raises(ValueError):
        maze_5x5.add_wall(1, 1, 'X')


def test_add_wall_at_border_raises(maze_5x5: Maze) -> None:
    """add_wall sur une bordure lève ValueError
    (condition de garde non remplie)."""
    with pytest.raises(ValueError):
        maze_5x5.add_wall(0, 0, 'N')  # y=0, condition y>0 fausse


# ── place_42_center ───────────────────────────────────────────────────


def test_place_42_center_empty_for_small_maze() -> None:
    """Maze 4×4 trop petit → forty_two_cells vide."""
    maze = Maze(4, 4)
    assert maze.forty_two_cells == set()


def test_place_42_center_populates_for_large_maze() -> None:
    """Maze 11×11 (≥ pw+4, ph+4) → forty_two_cells non vide."""
    maze = Maze(11, 11)
    assert len(maze.forty_two_cells) > 0


def test_place_42_center_cells_have_value_15() -> None:
    """Toutes les cellules du motif doivent valoir 15."""
    maze = Maze(11, 11)
    for (x, y) in maze.forty_two_cells:
        assert maze.grid[y][x] == 15


def test_place_42_center_is_horizontally_centered() -> None:
    """Le motif est centré : start_x == (width - pattern_width) // 2."""
    maze = Maze(11, 11)
    pw = len(maze.PATTERN_42[0])
    expected_start_x = (11 - pw) // 2
    xs = {x for (x, _) in maze.forty_two_cells}
    assert min(xs) == expected_start_x


def test_place_42_center_is_vertically_centered() -> None:
    maze = Maze(11, 11)
    ph = len(maze.PATTERN_42)
    expected_start_y = (11 - ph) // 2
    ys = {y for (_, y) in maze.forty_two_cells}
    assert min(ys) == expected_start_y


def test_place_42_center_minimum_size() -> None:
    """pw+4 colonnes et ph+4 lignes = taille minimale pour le motif."""
    ph = len(Maze.PATTERN_42)
    pw = len(Maze.PATTERN_42[0])
    maze = Maze(pw + 4, ph + 4)
    assert len(maze.forty_two_cells) > 0


def test_place_42_center_just_below_minimum_empty() -> None:
    """Un pixel en dessous du minimum → aucune cellule 42."""
    ph = len(Maze.PATTERN_42)
    pw = len(Maze.PATTERN_42[0])
    maze = Maze(pw + 3, ph + 4)  # une colonne de moins
    assert maze.forty_two_cells == set()
